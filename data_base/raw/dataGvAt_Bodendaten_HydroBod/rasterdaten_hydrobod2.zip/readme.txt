Erg�nzende Daten:

swm1 bis swm3: Daten zur speicherwirksamen M�chtigkeit (swm) der TS1 bis TS3 in cm
swm_gesamt: Daten zur speicherwirksamen M�chtigkeit (swm) gesamt in cm
gpv1_prozent bis gpv3_prozent: Daten zum Gesamtporenvolumen TS1 bis TS3 in Prozent
gpv1_mm bis gpv3_mm: Daten zum Gesamtporenvolumen TS1 bis TS3 in mm
pv1_prozent bis pv3_prozent: Daten zum Gesamtporenvolumen - Totwasser TS1 bis TS3 in Prozent
pv1_mm bis pv3_mm: Daten zum Gesamtporenvolumen - Totwasser TS1 bis TS3 in mm
bodenspeicher: gesamter Bodenwasserspeicher (ohne Totwasseranteil) in mm


BFW, Stand M�rz 2017
-----